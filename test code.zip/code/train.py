import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
import joblib
import skorch
from skorch import NeuralNetRegressor
from DRSN import DRSNet
import time
# Load data
data = pd.read_excel('data.xlsx')
# Split data into features (X) and targets (y)
X = data.iloc[:, :data.columns.get_loc("conversion")]
y = data.iloc[:, data.columns.get_loc("conversion"):]
# 数据标准化
xScaler = StandardScaler().fit(X)
yScaler = StandardScaler().fit(y)
# 保存标准化器
joblib.dump(xScaler, "xScaler.pkl")
joblib.dump(yScaler, "yScaler.pkl")
Xdata = xScaler.transform(X)
ydata = yScaler.transform(y)

# 把数据变成张量
Xdata = torch.tensor(Xdata,dtype=torch.float32)
ydata = torch.tensor(ydata,dtype=torch.float32)
# Split data into training and test sets
# 将测试集比例调整到10%，剩下90%数据作为训练集，在训练集中采用9折交叉验证训练，即训练集、验证集、测试集的比例为8：1：1
X_train, X_test, y_train, y_test = train_test_split(Xdata, ydata, test_size=0.1, random_state=42)

# Initialize and fit the MLPRegressor (Neural Network) for multi-target regression
# nn_model = MLPRegressor(hidden_layer_sizes=(100, 100), activation='relu', max_iter=500, random_state=42)
# 将torch定义的drsn进行包装，获得可以使用sklearn接口的估计器
drsn_model = NeuralNetRegressor(
    DRSNet,
    module__nodeNum = 30, # 节点数
    module__resNum = 30, # 残差块层数
    module__inDim = Xdata.size()[1], # 输入层节点数
    module__outDim = ydata.size()[1], # 输出层节点数
    criterion=nn.MSELoss,
    optimizer=optim.Adam,
    max_epochs = 200,
    train_split = skorch.dataset.ValidSplit(9), # 将验证集的比例设置为训练集的1/9，即总数据集被划分为训练集：验证集：测试集为80%：10%：10%
    device="cuda" if torch.cuda.is_available() else "cpu"
)

torch.manual_seed(42) # 设置torch过程中随机种子
time1 = time.time()
drsn_model.fit(X_train, y_train)
time2 = time.time()
# 保存模型用于预测和评估
torch.save(drsn_model, 'drsn_model.pth')
print('training time',time2-time1)

# 获取训练历史记录
history = drsn_model.history
# 绘制损失曲线
plt.figure(figsize=(10, 6))
plt.plot(history[:, 'train_loss'], label='Train Loss')
plt.plot(history[:, 'valid_loss'], label='Valid Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.yscale('log')  # 设置纵坐标为对数刻度
plt.axhline(y=1e-2, color='r', linestyle='--', label='10^-2')  # 添加水平线
plt.legend()
plt.title('Training and Validation Loss over Epochs')
plt.savefig('loss.png',dpi=600)

# Predict on training and test sets for all targets
y_train_pred = drsn_model.predict(X_train)
y_test_pred = drsn_model.predict(X_test)
# 反归一化
y_train_pred = yScaler.inverse_transform(y_train_pred)
y_test_pred = yScaler.inverse_transform(y_test_pred)
# Loop over each target to compute and display metrics individually
for idx, target_col in enumerate(y.columns):
    # Extract true and predicted values for the current target
    y_train_target = yScaler.inverse_transform(y_train)[:,idx]
    y_test_target = yScaler.inverse_transform(y_test)[:,idx]
    y_train_pred_target = y_train_pred[:, idx]
    y_test_pred_target = y_test_pred[:, idx]
    # Plotting true vs predicted for training set
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.scatter(y_train_target, y_train_pred_target, alpha=0.5)
    plt.plot([y_train_target.min(), y_train_target.max()], [y_train_target.min(), y_train_target.max()], 'r--')
    plt.xlabel("True Values")
    plt.ylabel("Predicted Values")
    plt.title(f"Training Set: True vs Predicted for {target_col}")
    # Plotting true vs predicted for test set
    plt.subplot(1, 2, 2)
    plt.scatter(y_test_target, y_test_pred_target, alpha=0.5)
    plt.plot([y_test_target.min(), y_test_target.max()], [y_test_target.min(), y_test_target.max()], 'r--')
    plt.xlabel("True Values")
    plt.ylabel("Predicted Values")
    plt.title(f"Test Set: True vs Predicted for {target_col}")
    plt.tight_layout()
    # plt.show()
    plt.savefig(f'{target_col}.png',dpi=600)
    # Calculate and display evaluation metrics for the current target
    train_r2 = r2_score(y_train_target, y_train_pred_target)
    test_r2 = r2_score(y_test_target, y_test_pred_target)
    train_mae = mean_absolute_error(y_train_target, y_train_pred_target)
    test_mae = mean_absolute_error(y_test_target, y_test_pred_target)
    print(f"--- Target: {target_col} ---")
    print(f"Training R² Score: {train_r2:.3f}")
    print(f"Test R² Score: {test_r2:.3f}")
    print(f"Training MAE: {train_mae:.3f}")
    print(f"Test MAE: {test_mae:.3f}\n")
    
# 保存测试集预测结果
df = pd.DataFrame(np.concatenate((xScaler.inverse_transform(X_test),yScaler.inverse_transform(y_test),y_test_pred),axis=1),columns=list(data.columns)+[i+'pred' for i in y.columns])
df.to_excel('test pred.xlsx',sheet_name='test pred',index=None)