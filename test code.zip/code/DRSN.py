from sklearn.neural_network import BernoulliRBM
import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')#使用GPU CPU

def data2numpy(data):
    '''张量转为CPU的numpy类型'''
    try:
        return data.detach().cpu().numpy()
    except:
        return data


class ResConvBlock(nn.Module):
    def __init__(self,nodeNum):
        super(ResConvBlock, self).__init__()
        # 这里定义了残差块内连续的2个卷积层
        self.left = nn.Sequential(
            nn.Conv2d(nodeNum, nodeNum, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(nodeNum),
            nn.PReLU(),  # 可以改成 nn.PReLU()
            nn.Conv2d(nodeNum, nodeNum, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(nodeNum)
        )
        self.relu = nn.PReLU()

    def forward(self, x):
        out = self.left(x)
        # 将2个卷积层的输出跟处理过的x相加，实现ResNet的基本结构
        out = x + out
        out = self.relu(out)
        return out

class ResFcBlock(nn.Module):
    def __init__(self, nodeNum):
        super(ResFcBlock, self).__init__()
        # 这里定义了残差块内连续的2个卷积层
        self.left = nn.Sequential(
            nn.Linear(nodeNum, nodeNum),
            nn.BatchNorm1d(nodeNum),
            nn.PReLU(),  # 可以改成 nn.PReLU()
            nn.Linear(nodeNum, nodeNum),
            nn.BatchNorm1d(nodeNum)
        )
        self.relu = nn.PReLU()

    def forward(self, x):
        out = self.left(x)
        # 将2个卷积层的输出跟处理过的x相加，实现ResNet的基本结构
        out = x + out
        out = self.relu(out)
        return out



class ResCnnNet(nn.Module):
    '''基于CNN的残差网络'''
    def __init__(self,nodeNum,resNum,inDim,outDim):
        super(ResCnnNet, self).__init__()
        nodeNum = int(nodeNum)
        resNum = int(resNum)
        inDim = int(inDim)
        outDim = int(outDim)
        self.inDim = inDim
        #修改通道供给残差块
        self.conv1 = nn.Conv2d(1, nodeNum, kernel_size=3, stride=1, padding=1)
        #残差层
        self.resList = [ResConvBlock(nodeNum) for i in range(resNum)]
        self.resList = nn.ModuleList(self.resList)
        self.conv2 = nn.Conv2d(nodeNum, 1, kernel_size=3, stride=1, padding=1)
        self.relu = nn.PReLU()
        #输出层
        self.fc = nn.Linear(inDim,outDim)

    def forward(self,x):
        x1 = self.conv1(x)
        x = x1
        for layer in self.resList:
            x = layer(x)
        x = x1 + x
        x = self.relu(x)
        x = self.conv2(x)
        x = x.reshape(-1,self.inDim)
        x = self.fc(x)
        return x

class ResFcNet(nn.Module):
    '''基于全连接的残差网络'''
    def __init__(self,nodeNum,resNum,inDim,outDim):
        super(ResFcNet, self).__init__()
        nodeNum = int(nodeNum)
        resNum = int(resNum)
        inDim = int(inDim)
        outDim = int(outDim)
        self.inDim = inDim
        #修改节点数供给残差块
        self.fc1 = nn.Linear(inDim,nodeNum)
        #残差层
        self.resList = [ResFcBlock(nodeNum) for i in range(resNum)]
        self.resList = nn.ModuleList(self.resList)
        self.relu = nn.PReLU()
        #输出层
        self.fc2 = nn.Linear(nodeNum,outDim)

    def forward(self,x):
        x = x.reshape(-1,self.inDim)
        x1 = self.fc1(x)
        x = x1
        for layer in self.resList:
            x = layer(x)
        x = x1 + x
        x = self.relu(x)
        x = self.fc2(x)
        return x



class RSBU_CW(torch.nn.Module):
    def __init__(self, nodeNum, down_sample=False):
        '''DRSN-CW的特殊残差层'''
        super().__init__()
        in_channels = nodeNum
        out_channels = nodeNum
        self.down_sample = down_sample
        self.in_channels = nodeNum
        self.out_channels = nodeNum
        stride = 2 if down_sample else 1
        self.BRC = nn.Sequential(
            nn.BatchNorm1d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=stride,
                      padding=1),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(in_channels=out_channels, out_channels=out_channels, kernel_size=3, stride=1,
                      padding=1)
        )
        self.global_average_pool = nn.AdaptiveAvgPool1d(1)
        self.FC = nn.Sequential(
            nn.Linear(in_features=out_channels, out_features=out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True),
            nn.Linear(in_features=out_channels, out_features=out_channels),
            nn.Sigmoid()
        )
        self.flatten = nn.Flatten()
        self.average_pool = nn.AvgPool1d(kernel_size=1, stride=2)

    def forward(self, input):
        x = self.BRC(input)
        x_abs = torch.abs(x)
        gap = self.global_average_pool(x_abs)
        gap = self.flatten(gap)
        alpha = self.FC(gap)
        threshold = torch.mul(gap, alpha)
        threshold = torch.unsqueeze(threshold, 2)
        # 软阈值化
        sub = x_abs - threshold
        zeros = sub - sub
        n_sub = torch.max(sub, zeros)
        x = torch.mul(torch.sign(x), n_sub)
        if self.down_sample:  # 如果是下采样，则对输入进行平均池化下采样
            input = self.average_pool(input)
        if self.in_channels != self.out_channels:  # 如果输入的通道和输出的通道不一致，则进行padding,直接通过复制拼接矩阵进行padding,原代码是通过填充0
            zero_padding = torch.zeros(input.shape).cuda()
            input = torch.cat((input, zero_padding), dim=1)
        result = x + input
        return result


class DRSNet(torch.nn.Module):
    def __init__(self,nodeNum,resNum,inDim,outDim):
        super().__init__()
        nodeNum = int(nodeNum)
        resNum = int(resNum)
        self.inDim = int(inDim)
        self.outDim = int(outDim)
        self.conv1 = nn.Conv1d(in_channels=inDim,out_channels=nodeNum,kernel_size=3, stride=1, padding=1)
        self.bn = nn.BatchNorm1d(nodeNum)
        self.relu = nn.ReLU()
        self.softmax = nn.Softmax(dim=1)
        self.global_average_pool = nn.AdaptiveAvgPool1d(1)
        self.flatten = nn.Flatten()
        # 残差层
        self.resList = [RSBU_CW(nodeNum) for i in range(resNum)]
        self.resList = nn.ModuleList(self.resList)
        self.linear = nn.Linear(in_features=nodeNum, out_features=self.outDim)

    def forward(self, input):  # 1*256
        input = input.reshape(-1,self.inDim,1)
        x = self.conv1(input)  # 4*128
        for layer in self.resList:
            x = layer(x)
        x = self.bn(x)
        x = self.relu(x)
        gap = self.global_average_pool(x)  # 16*1
        gap = self.flatten(gap)  # 1*16
        output_class = self.linear(gap)  # 1*8
        return output_class


if __name__ == "__main__":
    x = torch.zeros(2,1,1,2)
    resCnnNet = ResCnnNet(50,3,2,1)
    resFcNet = ResFcNet(50,3,2,1)
    drsn = DRSNet(50,3,2,1)
    print(resCnnNet(x).shape)
    print(resFcNet(x).shape)
    print(drsn(x).shape)