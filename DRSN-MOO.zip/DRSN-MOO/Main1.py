

import numpy as np
from pymoo.core.problem import ElementwiseProblem
import pandas as pd
import matplotlib.pyplot as plt
import time
from numpy import *


import pandas as pd
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
from Main_DRSN import *
import json
from copy import deepcopy
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
#starting time  


class MyProblem(ElementwiseProblem):

  
 

    def __init__(self):
        super().__init__(n_var=14,
                          n_obj=2,
                          n_constr=2,
                          xl=np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 0, 0]),
                          xu=np.array([4, 4, 0, 4, 0, 0, 0, 0, 0, 0, 0, 110, 10, 2]))

    def _evaluate(self, x, out, *args, **kwargs):



        
        #加载标准化模型
        #加载标准化模型
        xScaler = joblib.load("Static/xScaler.pkl")
        yScaler = joblib.load("Static/yScaler.pkl")
        #读取模型
        drsn = torch.load("Static/DRSN-CW.pth").eval()
        #drsn.load_state_dict(torch.load('Static/DRSN-CW.pth'))



        #print("------------------------------手动输入-----------------------------------")
        #data维度要与决策变量保持相同
        data = [x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11], x[12], x[13]]
        data = np.array(data).reshape(1,-1)
        data = xScaler.transform(data).reshape(-1,len(inCols)).tolist()
        drsn.eval()
        x = torch.FloatTensor(data).reshape(1,-1)
        # 转换为 NumPy 数组并打印
        x_numpy = x.numpy()
        #print("x (NumPy array):", x_numpy)
        yPred = drsn(x).detach().numpy().reshape(-1,len(outCols))
        yPred = yScaler.inverse_transform(yPred)#数据归一化还原
        yPred = np.round(yPred.tolist()[0],3)#保留3位小数
        #print("手动输入:")
        #print("输出:")
        #print(yPred)
        #print("-----------------------------------------------------------------------")
        
         # Set the CellValue, y to f1, 从0开始默认最小值
        f1 =  -yPred[0] 
        f2 = -yPred[5] 
        #f3 = yPred[2] 
        #f4 = -yPred[3] 
        
        #默认g＜0
        g1= -f1-89.9
        g2= -f2-83.4
        out["F"] = [f1,f2]
        out["G"] = [g1,g2]
        #out["F"] = [f1, f2, f3, f4]



problem = MyProblem()
     