# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 18:03:59 2022

@author: zhouxin
"""
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from Main1 import problem
import matplotlib.pyplot as plt
import time
import numpy as np
from pymoo.visualization.scatter import Scatter
from pymoo.decomposition.asf import ASF
from pymoo.mcdm.pseudo_weights import PseudoWeights
from pymoo.algorithms.soo.nonconvex.ga import GA
from pymoo.algorithms.moo.rnsga2 import RNSGA2
from pymoo.algorithms.moo.rvea import RVEA
from pymoo.algorithms.moo.age import AGEMOEA
from pymoo.algorithms.moo.ctaea import CTAEA
from pymoo.visualization.scatter import Scatter
import pandas as pd


############################################################求解方法GA
# start = time.time()
# algorithm = GA(
#     pop_size=100,# 种群大小
#     eliminate_duplicates=True)

# res = minimize(problem,
#                 algorithm,
#                 seed=1,
#                 verbose=False)

# print("Best solution found: \nX = %s\nF = %s" % (res.X, res.F))
# end = time.time()
# print('耗时：', end - start, '秒')

############################################################求解方法nsga3
#####create the reference directions to be used for the optimization
# start = time.time()
# ref_dirs = get_reference_directions("das-dennis", 2, n_partitions=200)
# algorithm = NSGA3(pop_size=200,
#                   ref_dirs=ref_dirs)

# # execute the optimization
# res = minimize(problem,
#                 algorithm,
#                 seed=1,
#                 termination=('n_gen', 400))
# end = time.time()
# print('耗时：', end - start, '秒')
# Scatter().add(res.F).show()
############################################################求解方法CTAEA
#####create the reference directions to be used for the optimization

# start = time.time()
# ref_dirs = get_reference_directions("das-dennis", 4, n_partitions=12)

# # create the algorithm object
# algorithm = CTAEA(ref_dirs=ref_dirs)

# # execute the optimization
# res = minimize(problem,
#                algorithm,
#                ('n_gen', 600),
#                seed=1,
#                verbose=False
#                )
# end = time.time()
# print('耗时：', end - start, '秒')
# ##############################################################求解方法nsga2
start = time.time()
algorithm = NSGA2(pop_size=20, elimate_duplicates=False)

res = minimize(problem,
                algorithm,
                ('n_gen', 200),
                verbose=True)
end = time.time()
##plt.scatter(res.F[:, 0], res.F[:, 1], marker="o", s=10)
##plt.grid(True)
##plt.show()
print('耗时：', end - start, '秒')
Scatter().add(res.F).show()
# ##############################################################求解方法Rnsga2
# start = time.time()
# # Define reference points
# ref_points = np.array([[-2.5, -5.1, -91.0], [-2.9, -6.9, -93.0]])
# pf = problem.pareto_front()
# # Get Algorithm
# algorithm = RNSGA2(
#     ref_points=ref_points,
#     pop_size=40,
#     epsilon=0.01,
#     normalization='front',
#     extreme_points_as_reference_points=False,
#     weights=np.array([0.1, 0.3, 0.6]))

# res = minimize(problem,
#                 algorithm,
#                 save_history=True,
#                 termination=('n_gen', 250),
#                 seed=1,
#                 pf=pf,
#                 disp=False)
# print('耗时：', end - start, '秒')
#############################################################求解方法4

# from pymoo.algorithms.moo.rvea import RVEA
# start = time.time()
# ref_dirs = get_reference_directions("das-dennis", 4, n_partitions=10)

# algorithm = RVEA(ref_dirs)

# res = minimize(problem,
#                 algorithm,
#                 termination=('n_gen', 400),
#                 seed=1,
#                 verbose=False)
# end = time.time()
# print('耗时：', end - start, '秒')
#############################################################后处理
# # 归一化
# X = res.X
# F = res.F
# approx_ideal = F.min(axis=0)
# approx_nadir = F.max(axis=0)
# nF = (F - approx_ideal) / (approx_nadir - approx_ideal)
# ###权重
# weights = np.array([0.3, 0.7])
# decomp = ASF()
# i = decomp.do(nF, 1/weights).argmin()

# print("Best regarding ASF: Point \ni = %s\nF = %s" % (i, F[i]))

# plt.figure(figsize=(7, 5))
# plt.scatter(F[:, 0], F[:, 1], s=30, facecolors='none', edgecolors='blue')
# plt.scatter(F[i, 0], F[i, 1], marker="x", color="red", s=200)
# plt.title("Objective Space")
# plt.show()
# ####################################################################
# #wi=((fmaxi−fi(x))/(fmaxi−fmini))/(∑Mm=1(fmaxm−fm(x))/(fmaxm−fminm))
# i = PseudoWeights(weights).do(nF)
# print("Best regarding Pseudo Weights: Point \ni = %s\nF = %s" % (i, F[i]))
# plt.figure(figsize=(7, 5))
# plt.scatter(F[:, 0], F[:, 1], s=30, facecolors='none', edgecolors='blue')
# plt.scatter(F[i, 0], F[i, 1], marker="x", color="red", s=200)
# plt.title("Objective Space")
# plt.show()


# ##############################################################

print(res.F)
print(res.X)

# Assuming res.F and res.X are numpy arrays or similar
# Create a DataFrame for F and X
df_F = pd.DataFrame(res.F, columns=[f'F{i+1}' for i in range(res.F.shape[1])])
df_X = pd.DataFrame(res.X, columns=[f'X{i+1}' for i in range(res.X.shape[1])])

# Create a writer object to save multiple sheets in one Excel file
with pd.ExcelWriter('results.xlsx') as writer:
    df_F.to_excel(writer, sheet_name='Objective_Functions', index=False)
    df_X.to_excel(writer, sheet_name='Decision_Variables', index=False)

print("Data successfully saved to 'results.xlsx'")