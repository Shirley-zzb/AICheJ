# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from torchsummary import summary
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
from Main_DRSN import *
import json
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

#预测文件名字
predFile = "predict.xlsx"

#加载标准化模型
xScaler = joblib.load("Static/xScaler.pkl")
yScaler = joblib.load("Static/yScaler.pkl")

#读取模型
drsn = torch.load("Static/DRSN-CW.pth").eval()
cnn = torch.load("Static/CNN.pth").eval()

#读取数据
data = pd.read_excel(predFile)
x = torch.FloatTensor(data[inCols].values).reshape(-1,1,1,len(inCols))

writer = pd.ExcelWriter("预测结果.xlsx")

def nnPredict(model,name):
    data2 = data.copy()
    yPred = model(x).detach().numpy().reshape(-1,len(outCols))
    yPred = yScaler.inverse_transform(yPred)#数据归一化还原
    cols = [name + " " + col for col in outCols]
    data2[cols] = yPred.tolist()
    data2.to_excel(writer,sheet_name=name,index=None)

nnPredict(drsn,"DRSN-CW")
nnPredict(cnn,"CNN-Resnet")
writer.close()